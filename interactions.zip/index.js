require("dotenv").config();
const { AoiClient, LoadCommands, AoiInviteSystem, Util } = require("aoi.js");
const {
    AoiVoice,
    PluginName,
    PlayerEvents,
    Cacher,
    Filter,
} = require(`@akarui/aoi.music`);
const { setup } = require("@akarui/aoi.parser");

const token_type = process.env.DISCORD_OPERATOR
const token = process.env.DISCORD_TOKEN
const allIntents = ["MessageContent", "Guilds", "GuildMessages", "GuildVoiceStates", "GuildMembers", "GuildBans", "GuildEmojisAndStickers", "GuildIntegrations", "GuildWebhooks", "GuildInvites", "GuildVoiceStates", "GuildPresences", "GuildMessageReactions", "GuildMessageTyping", "DirectMessages", "DirectMessageReactions", "DirectMessageTyping"]

// web page
const express = require("express");
const cors = require('cors');
const app = express();
const port = (token_type == "STABLE") ? 8080 : 3004;
const path = require("path");
const fs = require("fs");

const bot = new AoiClient({
    token: token,
    prefix: (token_type == "STABLE") ? process.env.DISCORD_PREFIX : "--",
    intents: allIntents,
    events:["onMessage", "onInteractionCreate","onGuildJoin","onMessageUpdate","onFunctionError","onVoiceStateUpdate","onJoin","onLeave","onChannelDelete","onEmojiCreate"],
    suppressAllErrors: (token_type == "STABLE") ? true : false,
    errorMessage: "⚠️ **There's an error. Here we go again...**\nThis can be situacional by some instability or, if persists, contact the developer for bugfixes.",
    database: {
        type: "aoi.db",
        db: require("@akarui/aoi.db"),
        tables: ["main"],
        path: "./database/",
        extraOptions: {
            dbType: "KeyValue"
        }
    },
    fetchInvites: {
        cacheInviters: true,
        enabled: true,
    },
    aoiAutoUpdate: true
});

bot.status({
    text:"$allMembersCount users",
    type: "WATCHING",
    status: "idle",
    afk: true,
    time: 10
})
bot.status({
    text:"$guildCount servers",
    type: "WATCHING",
    status: "idle",
    afk: true,
    time: 10
})
bot.status({
    text: "ryan.rydermais.com",
    url: "https://ryan.rydermais.com",
    type: "STREAMING",
    status: "idle",
    afk: true,
    time: 20
})
    

bot.readyCommand({
    channel: "",
    code: `  
    $log[
      ─━━━━━━━━━Ready━━━━━━━━━─
      Client: $userTag[$clientID]
      Ping: $ping ms | Servers: $guildCount | Users: $allMembersCount
      Bot Creator: $username[$clientOwnerIDs]#$discriminator[$clientOwnerIDs]
      Commands loaded: $commandsCount
      Panel: http://localhost:`+ port +`
      ─━━━━━━━━━━━━━━━━━━━━━━━━─
    ];
    $log[Logging in with ` + token_type + ` token...];
    $sendDM[{newEmbed: {title:\:white_check_mark\:$username[$clientID]#$discriminator[$clientID] is online!}{color:#27217E}
    {field:Ping: $ping ms:yes}
    {field:Guilds: $guildCount:yes}
    {field:Users: $allMembersCount:yes}
    {field:Commands: $commandsCount:yes}
    {field:Port: `+ port +`:yes}
    {field:Env: ` + token_type + `:yes}
    };$clientOwnerIDs];
    $eval[startAPI()];
    `, 
    executeOnStartup: true,
}),

require('./database/variables.js')(bot);

const voice = new AoiVoice(bot, {
    searchOptions: {
        youtubeClient: "WEB",
        youtubegl: "BR",
    },
    requestOptions: {
        offsetTimeout: 0,
        soundcloudLikeTrackLimit: 200,
        youtubePlaylistLimit: 10,
    },
    devOptions: {
        debug: (token_type == "STABLE") ? false : true,
    },
});
voice.addPlugin(PluginName.Cacher, new Cacher("disk"));
voice.addPlugin(PluginName.Filter, new Filter({
    filterFromStart: true,
}));
voice.addEvent(PlayerEvents.TrackStart);
voice.addEvent(PlayerEvents.TrackEnd);
voice.addEvent(PlayerEvents.QueueStart);
voice.addEvent(PlayerEvents.QueueEnd);


const loader = new LoadCommands(bot);
loader.load(bot.cmd, "./commands/")
loader.load(bot.cmd, "./interactions/")
loader.load(bot.cmd, "./events/client/")
loader.load(voice.cmds, "./events/voice/");
voice.bindExecutor(bot.functionManager.interpreter);

setup(Util);


// or enable CORS for specific origins
const whitelistCORS = [
    'https://ryan.rydermais.com',
    'https://ryan.discloud.app',
    'https://rydermais.com',
    'https://rydermais.discloud.app',
    'http://localhost:3004',
];

// if not stable, add localhost scenarios to whitelist
whitelistCORS.push("http://localhost:" + port);
whitelistCORS.push("http://localhost:8080");
whitelistCORS.push("http://localhost");
whitelistCORS.push("https://localhost");

// when path start with "/api", always return in JSON format
app.use("/api", (req, res, next) => {
    res.setHeader("Content-Type", "application/json");
    next();
});

app.use(
    cors({
        origin: function (req, callback) {
            if (whitelistCORS.indexOf(req) !== -1) {
                callback(null, true)
            } else {
                callback(new Error('Requests under "' + origin + '" origin aren\'t allowed by CORS'))
            }
        }
    })
);

app.get("/api/client/uptime", (req, res) => {
    res.send(`${bot.uptime}`);
});
app.get("/api/client/ping", (req, res) => {
    res.send(`${bot.ws.ping}`);
});
app.get("/api/client/status", (req, res) => {
    res.send(`${bot.status}`);
});
app.get("/api/client/info", (req, res) => {
    // if not ready, return
    if (!bot.users.cache.size) return res.send({
        "error": [
            "The system wasn't fully loaded yet. Please wait a few seconds and try again.",
            "If the problem persists, contact the developer.",
            "https://ryan.rydermais.com/contact"
        ],
        "status": {
            "uptime": bot.uptime,
            "ping": bot.ws.ping
        }
    });
    let _bot = { "bot": bot.user };
    // add bot owner into bot info
    let _ownerID = bot.application.owner || null;
    // get the owner name at any guild cache. When the first result is found, stop the loop
    try {
        bot.guilds.cache.forEach(guild => {
            if (_ownerID) return;
            guild.members.cache.forEach(member => {
                if (_ownerID) return;
                if (member.user.id != bot.application.owner.id) return;
                _ownerID = member.user;
                console.log(_ownerID);
            });
        });
    } catch (error) {
        console.error(error);
    }
    if (_ownerID) {
        _bot.bot.owner = {
            "username": _ownerID.username,
            "globalName": _ownerID.globalName,
            "discriminator": _ownerID.discriminator,
            "id": _ownerID.id,
            "avatarURL": `https://cdn.discordapp.com/avatars/${_ownerID.id}/${_ownerID.avatar}.png`,
            "bannerURL": `https://cdn.discordapp.com/banners/${_ownerID.id}/${_ownerID.banner}.png`,
            "accentColor": _ownerID.accentColor || 0,
            "accentColorHex": "#" + _ownerID.accentColor.toString(16).padStart(6, "0"),
        }
    } else {
        _bot.bot.owner = {
            "username": "Unknown",
            "discriminator": "0000",
            "id": "000000000000000000"
        }
    }
    // add bot invite link into bot info
    _bot.bot.invite = `https://discord.com/oauth2/authorize?client_id=${bot.user.id}&scope=bot%20applications.commands&permissions=8`;
    let _stats = {
        "status": {
            "uptime": bot.uptime || undefined,
            "ping": bot.ws.ping || undefined,
            "guilds": bot.guilds.cache.size || undefined,
            "users": bot.users.cache.size || undefined
        }
    }
    res.send(Object.assign(_bot, _stats));
});
app.get("/api/guilds", (req, res) => {
    res.send(`${bot.guilds.cache.size}`);
});
app.get("/api/guilds/list", (req, res) => {
    let guilds = [];
    let id = [];
    bot.guilds.cache.forEach(guild => {
        guilds.push(guild.name);
        id.push(guild.id);
    });

    // send as JSON
    res.setHeader("Content-Type", "application/json"); 
    res.send(`{"guilds": {${id.map((id, index) => `"${id}": "${guilds[index]}"`).join(", ")}}, length: ${bot.guilds.cache.size}}`);
    // rework tnis send as JSON
    res.send(`{"guilds": {${id.map((id, index) => `"${id}": "${guilds[index]}"`).join(", ")}}}`);

});
app.get("/api/guild/:id/info", (req, res) => {
    let guild = bot.guilds.cache.get(req.params.id);
    if (!guild) return res.send("Guild not found.");
    let response = {
        "name": guild.name || undefined,
        "id": guild.id || undefined,
        "ownerID": guild.ownerID || undefined,
        "region": guild.region || undefined,
        "memberCount": guild.memberCount || undefined,
        "createdAt": guild.createdAt || undefined,
        "iconURL": guild.iconURL() || undefined,
        "bannerURL": guild.bannerURL() || undefined,
        "splashURL": guild.splashURL() || undefined,
        "afkChannel": guild.afkChannel || undefined,
        "afkTimeout": guild.afkTimeout || undefined,
        "systemChannel": guild.systemChannel || undefined,
        "systemChannelFlags": guild.systemChannelFlags || undefined,
        "verificationLevel": guild.verificationLevel || undefined,
        "explicitContentFilter": guild.explicitContentFilter || undefined,
        "mfaLevel": guild.mfaLevel || undefined,
        "premiumTier": guild.premiumTier || undefined,
        "premiumSubscriptionCount": guild.premiumSubscriptionCount || undefined,
        "vanityURLCode": guild.vanityURLCode || undefined,
        "description": guild.description || undefined,
        "features": guild.features || undefined,
        "emojis": guild.emojis.cache.map(emoji => emoji.toString()) || undefined,
        // roles: ["name", "color", "totalMembers", "position", "hexColor"]
        "roles": guild.roles.cache.map(role => {
            return {
                "name": role.name,
                "hexColor": (role.color == 0) ? null : role.hexColor,
                "position": role.position,
            }
        }).sort((a, b) => b.position - a.position) || undefined,
        "channels": guild.channels.cache.map(channel => {
            return {
                "name": channel.name,
                "type": channel.type,
                "id": channel.id,
                "position": channel.position,
                "parent": channel.parent || undefined,
            }
        }).sort((a, b) => b.position - a.position) || undefined,
        "members": guild.members.cache.map(member => member.toString()) || undefined,
    };
    res.send(response);
});
// check users in guild
app.get("/api/guild/:id/users", (req, res) => {
    let guild = bot.guilds.cache.get(req.params.id);
    if (!guild) return res.send("Guild not found.");
    res.send(`${guild.memberCount}`);
});
// list users in guild
app.get("/api/guild/:id/users/list", (req, res) => {
    let guild = bot.guilds.cache.get(req.params.id);
    if (!guild) return res.send("Guild not found.");
    let users = [];
    let usersID = [];
    guild.members.cache.forEach(member => {
        (member.user.discriminator != "0" && member.user.discriminator != undefined)
            ? users.push(`${member.user.username}#${member.user.discriminator}`)
            : users.push(member.user.username);
        usersID.push(member.user.id);
    });
    res.setHeader("Content-Type", "application/json"); // order user ID ascending
    res.send(`{"users": {${usersID.map((id, index) => `"${id}": "${users[index]}"`).join(", ")}}}`);
});
app.get("/api/guild/:id", (req, res) => {
    res.setHeader("Content-Type", "application/json");
    // list all endpoints
    res.send(`{"endpoints": 
        {"VALUE": {
            "GET: /guilds": "(INT) Total of guilds the bot is in.",
            "GET: /users": "(INT) Total of users the bot can see.",
        },
        "JSON": {
            "GET: /guilds/list": "(JSON) All guilds the bot is in.",
            "GET: /guild/:id/users/list": "(JSON) All users in a guild.",
        },
    }`);
});
app.get("/api/users", (req, res) => {
    res.send(`${bot.users.cache.size}`);
});
app.get("/api/users/list", (req, res) => {
    let users = [];
    let usersID = [];
    bot.users.cache.forEach(user => {
        (user.discriminator != "0" && user.discriminator != undefined)
            ? users.push(`${user.username}#${user.discriminator}`)
            : users.push(user.username);
        usersID.push(user.id);
    });
    res.setHeader("Content-Type", "application/json"); // order user ID ascending
    res.send(`{"users": {${usersID.map((id, index) => `"${id}": "${users[index]}"`).join(", ")}}}`);
});
app.get("/api/commands", (req, res) => {
    res.send(`${bot.cmd.commands.length}`);
});
app.get("/api/commands/list", (req, res) => {
    res.send(`${bot.cmd.commands.map(command => command.name).join(", ")}`);
});
app.get("/api/interactions", (req, res) => {
    res.send(`${bot.interaction.commands.length}`);
});
app.get("/api/", (req, res) => {
    // show all endpoints
    res.setHeader("Content-Type", "application/json");
    res.send(`{"endpoints":
        {"VALUE": {
            "GET: /uptime": {
                "description": "Bot uptime in milliseconds.",
                "example": {
                    request: "http://localhost:`+ port +`/uptime",
                    response: "123456789"
                }
            }
            "GET: /ping": "(INT) Bot ping in milliseconds.",
            "GET: /status": "(STRING) Bot status.",
            "GET: /guilds": "(INT) Total of guilds the bot is in.",
            "GET: /users": "(INT) Total of users the bot can see.",
            "GET: /commands": "(INT) Total of commands the bot has.",
            "GET: /interactions": "(INT) Total of interactions the bot has.",
        },
        "JSON": {
            "GET: /guilds/list": "(JSON) All guilds the bot is in.",
            "GET: /guild/:id/users/list": "(JSON) All users in a guild.",
            "GET: /users/list": "(JSON) All users the bot can see.",
            "GET: /commands/list": "(JSON) All commands the bot has.",
            "GET: /interactions/list": "(JSON) All interactions the bot has.",
        },
    }`);
});

async function startAPI() {
    if (token_type == "STABLE") {
        try {
            await app.listen(port, () => {
                console.log(`REST API running locally at http://localhost:${port}`);
            });
        } catch (error) {
            console.error(`Web page failed to start since the port ${port} is already in use.`);
        }
        return;
    }
    let attempts = 0;
    while (attempts < 10) {
        try {
            await app.listen(port, () => {
                console.log(`REST API running locally at http://localhost:${port}`);
            });
            break;
        } catch (error) {
            attempts++;
            if (attempts >= 10) {
                console.error("Web page failed to start since the original port and 10 random ports were already in use.");
                break;
            }
            port = Math.floor(Math.random() * 10000);
        }
    }
}

startAPI()