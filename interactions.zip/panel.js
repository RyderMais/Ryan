require("dotenv").config();
const { Panel } = require("@akarui/aoi.panel");
const { AoiClient } = require("aoi.js");
const bot = require("./index.js");

