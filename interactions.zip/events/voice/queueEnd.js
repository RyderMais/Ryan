module.exports = [{
    type: "queueEnd",
    channel: "$channelID",
    code: `
        $leaveVC
    `
}]