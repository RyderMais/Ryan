module.exports = [{
    type: "queueStart",
    channel: "$channelID",
    code: `
        
    `
}]