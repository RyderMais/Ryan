module.exports = [{
    type: "trackEnd",
    code: `
        $leaveVC[$voiceID]
    `
}] 