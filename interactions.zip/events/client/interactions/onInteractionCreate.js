module.exports ={
    name: "createApplicationCommand",
    code: `
  $createApplicationCommand[guildID/global;help;create;true;slash]`
}